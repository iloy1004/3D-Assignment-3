------------------------------------------------------------------------------------------------------
***************************** JURASSIC PACK *****************************
------------------------------------------------------------------------------------------------------
    
	Thank you for purchasing/downloading this model/Dino Pack. 
    
	This asset contains 3 folders, dino, eye and demo folder, dino folder only
	contains the FBX model with animations and textures.

	The "demo" folder is optional, there is a animation controller and a script
	allowing the dino to move in all direction, play animations and sounds.
	MainCam script is used to control the camera and display tools like fullscreen,
	fps, wireframe mode, model scale...

	"dino" folder : FBX file, dino textures/material.
	
	"eyes" folder : Shared eyes textures for dinos, allow to change the eye
	texture for all dinos.


Dino List
*********
    
Jurassic Pack vol. 1
------------------------------------------------------------------------------------------------------
	Ankylosaurus
	Brachiosaurus
	Compsoghathus FREE
	Dilophosaurus
	Dimetrodon
	Oviraptor
	Parasaurolophus
	Pteranodon
	Velociraptor
	Tyrannosaurus Rex
	Spinosaurus
	Stegosaurus
	Triceratops

Jurassic Pack vol. 2
------------------------------------------------------------------------------------------------------
	Pachycephalosaurus
	Argentinosaurus - coming soon !
	Carnotaurus - coming soon !
	Gallimimus - coming soon !
	Styracosaurus - coming soon !
	Iguanodon - coming soon !
	Quetzalcoatlus - coming soon !
	Dimorphodon - coming soon !
	Kentrosaurus - coming soon !
	Baryonyx - coming soon !
	Protoceratops - coming soon !
	Corythosaurus - coming soon !
	Ornithocheirus - coming soon !


 
Contact
------------------------------------------------------------------------------------------------------
muelsa373@gmail.com

If you have any, question, suggestion or request, do not hesitate to
contact me :).
